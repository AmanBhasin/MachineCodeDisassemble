Follow the steps to Compile and Run the code:
1. Download the Files and make sure to save them in the same folder. So that there shouldn't be any problem of paths
2. In the terminal, Compile the code with command g++ <filename.cpp> 
3. a.out file will get form, run the command ./a.out
4. Modified assembly code will get printed on the scree.